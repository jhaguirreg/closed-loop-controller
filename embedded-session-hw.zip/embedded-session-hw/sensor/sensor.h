// Garantizo que no se haga la doble importación.
#ifndef SENSOR_H
#define SENSOR_H

void sensor_init(void);
double sensor_read(void);

#endif // SENSOR_H

